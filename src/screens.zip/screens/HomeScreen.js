import React, { Component } from "react";
import {
  StyleSheet,
  SafeAreaView,
  ScrollView,
  Text,
  Image,
  ImageBackground,
  View,
  Dimensions,
  Button,
  TouchableOpacity,
  Animated
 } from "react-native";

 import imgLevel from "../res/image/level_bkg.png"
 import imgProgressbar from "../res/image/progressbar.png"
 import imgPoint from "../res/image/point_bkg.png"
 import imgTopbar from "../res/image/topbar.png"
 import imgBottombar from "../res/image/bottombar.png"
 import imgArrowLeft from "../res/image/arrow_left.png"
 import imgArrowRight from "../res/image/arrow_right.png"
 import imgTagBkg from "../res/image/tag_bkg.png"
 import image001 from "../res/image/image001.png"
 import Swiper from 'react-native-swipe-image';
 import GallerySwiper from "react-native-gallery-swiper";

const DEVICE_WIDTH = Dimensions.get('window').width;
const DEVICE_HEIGHT = Dimensions.get('window').height;
const logHeight = DEVICE_WIDTH*866/1920;

export default class HomeScreen extends Component {
// class HomeScreen extends Component {
  constructor(props) {
    super(props);
    this.state = {
      images : [
        { url: "https://images.pexels.com/photos/1382734/pexels-photo-1382734.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500", name:"shakira" },
        { url: 'https://images.pexels.com/photos/9413/animal-cute-kitten-cat.jpg?cs=srgb&dl=adorable-animal-cat-9413.jpg&fm=jpg', name: "cat" },
        { url: 'https://i.pinimg.com/236x/c6/6b/11/c66b111bf4df809e87a1208f75d2788b.jpg', name: "baby" },
        { url: 'https://luehangs.site/pic-chat-app-images/beautiful-blond-blonde-hair-478544.jpg', name: "woman" },
      ],
      animatedValue: new Animated.Value(0)
    };
  }

  componentDidMount(){
    Animated.timing(this.state.animatedValue, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true, // <-- Add this
    }).start();
  }
  static navigationOptions = {
    header: null,
  }

  onPressOrder = () => {
    console.log('pressed!'); 
  }

  render() {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.header}>
          <View style={styles.levelItem}>
            <View style={styles.levelValueItem}>
              <Image
                style={styles.imgLevel} // must be passed from the parent, the number may vary depending upon your screen size
                source={imgLevel}
              />
              <Text style={styles.textLevelValue}>
                1
              </Text>
            </View>
            <Text style={styles.textLevel}>
              TRUST LVL
            </Text>
          </View>

          <View style={styles.progressbarItem}>
            <Image
              style={styles.imgProgressbar} // must be passed from the parent, the number may vary depending upon your screen size
              source={imgProgressbar}
            />
          </View>

          <View style={styles.levelItem}>
            <View style={styles.levelValueItem}>
              <Image
                style={styles.imgPoint} // must be passed from the parent, the number may vary depending upon your screen size
                source={imgPoint}
              />
              <Text style={styles.textLevelValue}>
                1200
              </Text>
            </View>
            <Text style={styles.textLevel}>
              POINTS
            </Text>
          </View>
        </View>

        <Image
          style={styles.imgTopbar} // must be passed from the parent, the number may vary depending upon your screen size
          source={imgTopbar}
        />

        <View style={styles.middleGroup}>
          <View style={styles.arrowLeft}>
            <Image
              style={styles.imgArrow} // must be passed from the parent, the number may vary depending upon your screen size
              source={imgArrowLeft}
            />
          </View>
          {/* <View style={styles.imageshow}> */}
            {/* <Image
                style={styles.imageView} // must be passed from the parent, the number may vary depending upon your screen size
                source={image001}
            /> */}
            {/* <Swiper
              // style={styles.imageView}
              images={this.state.images}
              swipeBottom={(e) => this.bottom(e)}
              swipeTop={(e) => this.top(e)}
              imageHeight={20}
              textSize={12}
              textBold={true}
              textColor={'red'}
              textUnderline={true}
            /> */}

          <GallerySwiper
            // images={[
            //     // Version *1.1.0 update (or greater versions): 
            //     // Can be used with different image object fieldnames.
            //     // Ex. source, source.uri, uri, URI, url, URL
            //     { uri: "https://luehangs.site/pic-chat-app-images/beautiful-blond-blonde-hair-478544.jpg" },
            //     { source: { uri: "https://luehangs.site/pic-chat-app-images/beautiful-beautiful-women-beauty-40901.jpg" } },
            //     { uri: "https://luehangs.site/pic-chat-app-images/animals-avian-beach-760984.jpg" },
            //     { URI: "https://luehangs.site/pic-chat-app-images/beautiful-blond-fishnet-stockings-48134.jpg" },
            //     { url: "https://luehangs.site/pic-chat-app-images/beautiful-beautiful-woman-beauty-9763.jpg" },
            //     { URL: "https://luehangs.site/pic-chat-app-images/attractive-balance-beautiful-186263.jpg" },
            // ]}
            images={this.state.images}
            style={styles.imageView}
            initialNumToRender={2}
            sensitiveScroll={false}
            useNativeDriver={true} // <-- Add this
          />
        
          {/* </View> */}
          <View style={styles.arrowLeft}>
            <Image
              style={styles.imgArrow} // must be passed from the parent, the number may vary depending upon your screen size
              source={imgArrowRight}
            />
          </View>
        </View>
        
        <Image
          style={styles.imgTopbar} // must be passed from the parent, the number may vary depending upon your screen size
          source={imgBottombar}
        />

      <ScrollView style={{height: 120}}>
        <View style={styles.bottom}>
          <View style={styles.tagGroup}>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
          </View>
          <View style={styles.tagGroup}>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.tagGroup}>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
          </View>
          
          <View style={styles.tagGroup}>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.tagItem} onPress={this.onPressOrder}>
                <Image
                  style={styles.imgTagBkg} // must be passed from the parent, the number may vary depending upon your screen size
                  source={imgTagBkg}
                />
                <Text style={styles.textTag}>
                  TAGS
                </Text>
            </TouchableOpacity>
          </View>
          
         </View>
          </ScrollView>
      </SafeAreaView>
    );
  }
}

// export default HomeScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: "rgba(0,0,0,1)",
    },
    background: {
        backgroundColor: "rgba(0,0,0,1)",
    },
    header: {
      // flex: 1,
      flexDirection: "row",
      // justifyContent: "space-between",
      backgroundColor: "rgba(0,0,0,1)",
      paddingTop: 5,
      height: 60,
    },
    levelItem: {
      flex: 0.7,
      alignItems: "center"
    },
    levelValueItem: {
      alignItems: "center",
      justifyContent: 'center',
    },
    progressbarItem: {
      flex: 3,
      alignItems: "center",
      textAlignVertical: "center",
      alignContent: "center",
      alignSelf: "center",
      marginHorizontal: 10,
    },
    textLevel: {
      color: '#ae7c31',
      fontSize: 10,
      textAlign: 'center',
    },
    textLevelValue: {
      fontSize: 12,
      position: 'absolute',
      color: '#ae7c31',
      justifyContent: "center",
      alignContent: "center",
      alignItems: "center",
      alignSelf: "center",
      textAlignVertical: "center"
    },
    imgLevel: {
      width: DEVICE_WIDTH/15,
      resizeMode: "stretch",
      height: DEVICE_WIDTH*1.3/15,
    },
    imgPoint: {
      width: DEVICE_WIDTH*1.3/15,
      resizeMode: "stretch",
      height: DEVICE_WIDTH*1.3/15,
    },
    imgProgressbar: {
      width: "100%",
      height: "30%",
      marginHorizontal: 0,
      resizeMode: "stretch",
      // textAlignVertical: "center",
      alignItems: "center"
      // flex: 8,
      // width: DEVICE_WIDTH/10,
      // resizeMode: "stretch",
      // height: DEVICE_WIDTH*1.3/10,
    },
    imgTopbar:  {
      width:"100%",
      height: 10,
      resizeMode: "stretch",
    },
    middleGroup: {
      flex: 10,
      flexDirection: "row",
      justifyContent: "space-between",
      backgroundColor: 'black',
      alignItems: "center",
    },
    arrowLeft: {
      alignItems: "center",
      // flex: 1,
      marginHorizontal: 10,
    },
    bottom: {
      flex: 3,
      paddingVertical: 3,
      backgroundColor: 'black',
    },
    imgArrow: {
      width: DEVICE_WIDTH/18,
      resizeMode: "stretch",
      height: DEVICE_WIDTH*1.8/18,
    },
    imageshow: {
      flex: 10,
      backgroundColor: "black",
      width: "100%",
      height: "100%",
      resizeMode: "stretch",
      alignSelf: "center"
    },
    imageView: {
      flex: 1,
      marginVertical: 3,
      marginHorizontal: 0,
      backgroundColor: "black",
      width: "100%",
      height: "100%",
      resizeMode: "stretch",
      alignSelf: "center"
    },
    imgTagBkg: {
      marginVertical: 2,
      marginHorizontal: 2,
      width: DEVICE_WIDTH/4.2,
      resizeMode: "stretch",
      height: DEVICE_WIDTH*1.3/15,
    },
    tagGroup: {
      flex: 1,
      flexDirection: "row",
      marginHorizontal: 10,
      justifyContent: "space-between",
      // alignItems: "center",
      alignSelf: "center",
    },
    tagItem: {
      alignItems: "center",
      justifyContent: 'center',
    },
    textTag: {
      position: 'absolute',
      color: "white",
      justifyContent: "center",
      alignContent: "center",
      alignItems: "center",
      alignSelf: "center",
      textAlignVertical: "center"
    }
});
